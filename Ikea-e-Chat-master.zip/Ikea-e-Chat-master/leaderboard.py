import discord
import random
from datetime import datetime, timedelta, date
import sqlite3
from db import dbopen
from embedmanager import embed

class leaderboard():
    #Parameters: Message = Messaged typed, Channels = channels that the leaderboard counter should count in, cooldown = seconds between messages counting to the leaderboard
    
    def __init__(self, name, message, channels, cooldown=0, name_printout=False,author_printout=False, perk=True):
        self.author=author_printout
        self.perk=perk
        self.name=name
        self.optional=name_printout
        self.path="../library/leaderboard/_"
        self.table="["+message.server.id+"_leaderboard]"
        self.table2="["+message.server.id+"_economy]"
        self.table3="["+message.server.id+"_owns]"
        self.table4="["+message.server.id+"_shop]"
        self.message=message
        self.channels=channels #list
        

        
        with dbopen('example.db') as c:
            # Creates table for leaderboard values if it dosen't exist
            c.execute('''CREATE TABLE if not exists {0} (id text PRIMARY KEY, date text, value integer, convert integer)'''.format(self.table))

            # Checks if message was typed in any of the channels in the list
            count=False
            for i in range(len(self.channels)):
                if self.message.channel.id==channels[i]:
                    count=True

            # Checks if author's unique ID can be found in database
            c.execute("SELECT * FROM {0} WHERE id=?".format(self.table), (message.author.id,))
            output=c.fetchall()
            
            # If user have not been found in database. It creates one
            if len(output)==0:
                t=(message.author.id, str(datetime.now()+timedelta(seconds=cooldown)), 1, 0)
                c.execute("INSERT INTO {0} values (?, ?, ?, ?)".format(self.table), t)
            elif count:
                t=(message.author.id,)
                c.execute("SELECT value,date FROM {0} WHERE id=?".format(self.table),t)
                data=c.fetchone()
                newdate=data[1]
                if newdate.find(".")!=-1:
                    newdate=newdate[:newdate.find(".")].strip()
                datetime_object = datetime.strptime(newdate,'%Y-%m-%d %H:%M:%S')
                if datetime_object<=datetime.now():       
                    t=(str(datetime.now()+timedelta(seconds=cooldown)),data[0]+1,message.author.id)
                    c.execute("UPDATE {0} SET date=?,value=? WHERE id=?".format(self.table),t)
    # Top, displays the top members who have chatted the most on the server, adjust how many with the "display_number" parameter. It generates everything into an embed, and returns it to the main routine.
    def drop(self):
        with dbopen("example.db") as c:
            c.execute("DROP TABLE {}".format(self.table))
            c.execute('''CREATE TABLE if not exists {0} (id text PRIMARY KEY, date text, value integer, convert integer)'''.format(self.table))
    def convert(self, display_image=None):
        with dbopen("example.db") as c:
            c.execute("SELECT value,convert FROM {} WHERE id=?".format(self.table),(self.message.author.id,))
            data=c.fetchone()
            value=data[0]
            diff=data[0]-data[1]
            increase=diff
            if self.perk:     
                c.execute("SELECT id FROM {} WHERE name IN(SELECT name FROM {} WHERE id=?)".format(self.table4,self.table3),(self.message.author.id,))
                data=c.fetchall()
                for perk in data:
                    if perk[0]==2:
                        increase=diff*2
                    if perk[0]==3:
                        increase=diff*3
                    if perk[0]==4:
                        increase=diff*4
            c.execute("SELECT currency FROM {} WHERE id=?".format(self.table2),(self.message.author.id,))
            data2=c.fetchone()
            c.execute("UPDATE {} SET currency=? WHERE id=?".format(self.table2),(data2[0]+increase,self.message.author.id,))
            c.execute("UPDATE {} SET convert=? WHERE id=?".format(self.table),(value,self.message.author.id))
            em=embed(message=self.message, description="\nConverted `"+str(diff)+"` messages to `"+str(increase)+"` "+self.name+".\nYour new balance is `"+str(data2[0]+increase)+"` "+self.name+".", author=self.author, image=display_image, optional_name=self.optional)
            return em

    def top(self,display_number, display_image=None, display_footer=None):
        self.url=display_image
        self.footer=display_footer
        if self.message.server.id=="381150170248642560":
            self.footer=None
        string=''
        counter2=0
        with dbopen('example.db') as c:
            c.execute("SELECT id,value FROM {} ORDER BY value DESC LIMIT {}".format(self.table, display_number))
            data=c.fetchall()
        counter=0
        for value in data:
            find=discord.utils.get(self.message.server.members, id=value[0])
            optionalname=""
            mention=""
            try:
                if self.optional:
                    optionalname=find.name
                mention=find.mention
            except (AttributeError):
                if self.optional:
                    optionalname="<user missing>"
                mention="<@{}>".format(value[0])

            counter+=1
            string+='**'+str(counter)+'. '+optionalname+' '+mention+': '+str(value[1])+' messages** \n'
        em=embed(message=self.message,title="Weekly Activity Leaderboard", description=string, image=display_image, footer=self.footer)
        return em
    def rank(self, index, show_position=True, show_user=True, display_image=None):
        with dbopen("example.db") as c:
            c.execute("SELECT id,value FROM {} ORDER BY value DESC".format(self.table))
            data=c.fetchall()
            checker=self.message.author
            string=""
            try:
                gotdata=int(self.message.content[len(index):].strip())
            except (ValueError, IndexError):
                try:
                    gotdata=self.message.mentions[0]
                except (ValueError, IndexError):
                    string+="You've"
                else:
                    checker=self.message.mentions[0]
                    string+=str(checker.name)        
                counter=0
                for user in data:
                    counter+=1
                    if user[0]==checker.id:
                        string+=" posted **"+str(user[1])+"** messages this week\nCurrently rank **#"+str(counter)+"** on the leaderboard."
                        break
                em=embed(message=self.message, description=string, author=self.author, image=display_image, optional_name=self.optional)
            else:
                position=int(self.message.content[len(index):].strip())
                ids=""
                try:
                    ids=data[position-1][0]
                except (IndexError, ValueError):
                    em=embed(self.message,description="That rank dosen't exist")
                else: 
                    find=discord.utils.get(self.message.server.members, id=ids)
                    string=str(find.name)+" posted **"+str(data[position-1][1])+"** messages this week\nCurrently rank **#"+str(position)+"** on the leaderboard."
                    em=embed(message=self.message, description=string, author=self.author, image=display_image, optional_name=self.optional)
            return em