import discord
import random
from datetime import datetime, timedelta, date
import sqlite3
from db import dbopen
from embedmanager import embed
def get_date(timestamp):
    months=["0","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
    clock=int(str(timestamp)[11]+str(timestamp)[12])
    ampm="AM"
    if clock>=12:
        clock=clock-12
        ampm="PM"
    time=str(clock)+":"+str(str(timestamp)[14]+str(timestamp)[15])+" "+ampm
    month=str(timestamp)[5]+str(timestamp)[6]
    if int(month[0])==0:
        month=int(str(timestamp)[6])
    else:
        month=int(str(timestamp)[5]+str(timestamp)[6])
    datestring=months[month]+" "+str(timestamp)[8]+str(timestamp)[9]+", "+str(timestamp)[:4].strip()+" "+time
    return datestring

def avatar(message, big=False):
    run=True
    checker=message.author
    try:
        gotdata=message.mentions[0]
    except (ValueError, IndexError):
        gotdata="null"
        checker=message.author
    else:
        checker=message.mentions[0]
    size=str(128)
    urls=str(checker.avatar_url)[:len(checker.avatar_url)-4].strip()
    if len(urls)==0:
        urls=str(checker.default_avatar_url)
    else:   
        urls+=size
    if message.content.endswith("big") and big==True:
        urls=str(checker.avatar_url)              
    em=discord.Embed(title="",description="", colour=0x399f99)
    em.set_image(url=urls)
    return em

def profile(message, client, currency_name, perk_opt, collect_opt, author_printout=False):
    em=embed(message,description="You entered the command incorrectly")
    checker=message.author
    run=True
    try:
        gotdata=message.mentions[0]
    except (ValueError, IndexError):
        gotdata="null"
        pass
    else:
        try:
            gotdata=message.mentions[1]
        except (ValueError, IndexError):
            checker=message.mentions[0]
        else:
            run=False
    if run==True:
        with dbopen("example.db") as c:
            get_date(checker.joined_at)
            em=embed(message=message, author=author_printout, image=checker.avatar_url)
            em.add_field(name="Joined at",value=get_date(checker.joined_at), inline=True)
            position=0
            counter=0
            positions=[]
            for member in message.server.members:
                if member.bot==False:
                    positions.append(member)
            positions.sort(key = lambda x: x.joined_at)
            for member in positions:
                counter+=1
                if member.id==checker.id:
                    position=counter
            em.add_field(name="Join Position",value=str(position), inline=True)
            em.add_field(name="Registered",value=get_date(checker.created_at), inline=True)
            c.execute("SELECT currency FROM {} WHERE id=?".format("["+message.server.id+"_economy]"),(checker.id,))
            data=c.fetchone()
            em.add_field(name="Wealth",value=str(data[0])+" "+currency_name, inline=True)
            counter=0
            amount=0
            c.execute("SELECT id,value FROM {} ORDER BY value DESC".format("["+message.server.id+"_leaderboard]"))
            data=c.fetchall()
            for user in data:
                counter+=1
                if user[0]==checker.id:
                    amount=user[1]
                    break
            em.add_field(name="Weekly Rank",value="#"+str(counter), inline=True)
            em.add_field(name="Weekly Messages",value=str(amount), inline=True)
            string=""
            c.execute("SELECT send_id, rec_id, date FROM {} WHERE status=? AND (send_id=? OR rec_id=?)".format("["+message.server.id+"_marriage]"),(1,checker.id,checker.id))
            data=c.fetchone()
            if data==None:
                string="None"
            else:
                ids=""
                try:
                    if data[0]==checker.id:
                        ids=data[1]
                        member=discord.utils.get(message.server.members, id=ids)
                        string=member.mention

                    elif data[1]==checker.id:
                        ids=data[0]
                        member=discord.utils.get(message.server.members, id=ids)
                        string=member.mention

                except (AttributeError):
                    string="<@{}>".format(ids)
        
            em.add_field(name="Married to",value=string, inline=True)
            perk_string=""
            collect_string=""
            c.execute("SELECT emj_name,perk FROM {} WHERE name IN(SELECT name FROM {} WHERE id=?)".format("["+message.server.id+"_shop]","["+message.server.id+"_owns]"),(checker.id,))
            emj=c.fetchall()
            for data in emj:
                if data[1]==1:
                    perk_string+=data[0]+" "
                elif data[1]==0:
                    collect_string+=data[0]+" "
            if len(perk_string)==0:
                perk_string="None"
            if len(collect_string)==0:
                collect_string="None"
            em.add_field(name=collect_opt[0].upper()+collect_opt[1:].strip(),value=collect_string, inline=False)
            em.add_field(name=perk_opt[0].upper()+perk_opt[1:].strip(),value=perk_string, inline=True)
            roles=""
            counter=0
            for role in checker.roles:
                if counter>1:
                    roles+=", "
                counter+=1
                if counter!=1:
                    roles+="`"+str(role)+"`"
            if counter==1:
                roles="None" 
            em.add_field(name="Roles",value=roles, inline=True)
    return em        