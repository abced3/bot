import discord
import random
from datetime import datetime, timedelta, date
from game import randomizer
from db import dbopen
from embedmanager import embed

class economy():
    # message = current message
    # currency_name = Name of the currency on the server in plural (ex. coins, and not coin)
    # currency_typing_aquire = If you want the servers members to be able to gather a specific amount of currency when they're being active (typing messages)
    # currency_typing_frequency = The number of messages you have to type before aquiring currency of selected amount
    # currency_amount_aquire = The amount of currency you aquire after selected messages have been typed out (currency_typing_frequency)
    # name_printout = When using a command which includes a user's name in the embed it includes a "mention" of this person, though on mobile devices this is displayed as an
    #                 ID number. So by enabling this option. You'll have a "un-mentioned" name next to it, which will help mobile users detirmine what user is in the embed

    def __init__(self, message, currency_name, name_printout=False, author_printout=False, currency_typing_aquire=False, currency_typing_frequency=0, currency_amount_aquire=0, cooldown=0, perk=True):
        self.perk=perk
        self.table="["+message.server.id+"_economy]"
        self.table2="["+message.server.id+"_cooldown]"
        self.table3="["+message.server.id+"_owns]"
        self.table4="["+message.server.id+"_shop]"
        self.optional=name_printout
        self.author=author_printout
        self.message=message
        self.name=currency_name
        self.aquire=currency_typing_aquire
        self.freq=currency_typing_frequency
        self.amount=currency_amount_aquire     
        with dbopen('example.db') as c:
            c.execute('''CREATE TABLE if not exists {} (id text PRIMARY KEY, date text, currency integer, counter integer)'''.format(self.table))
            gotdata=""
            try:
                gotdata=message.mentions[0]
            except (ValueError, IndexError):
                pass
            finally:
                if len(str(gotdata))!=0:
                    c.execute("SELECT currency,counter FROM {} WHERE id=?".format(self.table),(gotdata.id,))
                    data=c.fetchall()
                    if len(data)==0:
                        t=(gotdata.id, str(datetime.now()+timedelta(seconds=cooldown)), 0,1)
                        c.execute("INSERT INTO {0} values (?, ?, ?, ?)".format(self.table), t)

                c.execute("SELECT currency,counter FROM {} WHERE id=?".format(self.table),(message.author.id,))
                data=c.fetchall()
                if len(data)==0:
                    t=(message.author.id, str(datetime.now()+timedelta(seconds=cooldown)), 0,1)
                    c.execute("INSERT INTO {0} values (?, ?, ?, ?)".format(self.table), t)

                if currency_typing_aquire:
                    c.execute("SELECT currency,counter,date FROM {0} WHERE id=?".format(self.table),(message.author.id,))
                    data=c.fetchone()
                    datetime_object = datetime.strptime(data[2],'%Y-%m-%d %H:%M:%S.%f')
                    if datetime_object<=datetime.now(): 
                        if data[1]>=currency_typing_frequency:
                            t=(str(datetime.now()+timedelta(seconds=cooldown)),1,data[0]+currency_amount_aquire,message.author.id)
                            c.execute("UPDATE {0} SET date=?,counter=?,currency=? WHERE id=?".format(self.table),t)
                        else:
                            t=(str(datetime.now()+timedelta(seconds=cooldown)),data[1]+1,message.author.id)
                            c.execute("UPDATE {0} SET date=?,counter=? WHERE id=?".format(self.table),t)

                
    # option_unlock = If you want to be able to unlock the option to be able to bet on a specific side of the "coin" (ex. Heads or Tails)
    # option_heads = In case you want to change the command for betting on head.
    # option_tails = In case you want to change the command for betting on tails.

    # Change randomizer so we can remove members

    def coinflip(self, members, index, option_unlock=False, option_heads="heads", option_tails="tails", option_two_heads="h", option_two_tails="t", option_heads_image="https://cdn.discordapp.com/attachments/327023908454793219/366681156474634250/Heads_Edited.png", option_tails_image="https://cdn.discordapp.com/attachments/327023908454793219/366681227765219328/Tails_Edited.png"):    
        string=""
        em=embed(self.message,description="You entered the command incorrectly")
        if not option_unlock:
            option_heads=""
            option_tails=""
        ranvar=randomizer(members)
        option=index
        pickvar=0
        run=False
        if not option_unlock:
            run=True
        if self.message.content.find(index+" "+option_two_heads)!=-1 or self.message.content.find(index+" "+option_heads)!=-1:
            if option_unlock:
                run=True
                if self.message.content.find(index+" "+option_heads)!=-1:
                    pickvar=1
                    option=index+" "+option_heads
                else:
                    pickvar=1
                    option=index+" "+option_two_heads
        if self.message.content.find(index+" "+option_two_tails)!=-1 or self.message.content.find(index+" "+option_tails)!=-1:
            if option_unlock:
                run=True
                if self.message.content.find(index+" "+option_tails)!=-1:
                    pickvar=0
                    option=index+" "+option_tails
                else:
                    pickvar=0
                    option=index+" "+option_two_tails
        if run:
            gamble=self.message.content[len(option):].strip()
            try:
                gotdata=int(gamble)
            except (IndexError, ValueError):
                gotdata='null'
            else:
                gamble=int(gamble)
                if gamble>=1:
                    with dbopen("example.db") as c:
                        c.execute("SELECT currency from {} WHERE id=?".format(self.table),(self.message.author.id,))
                        data=c.fetchone()
                        if data[0]>=gamble:
                            if option_unlock:
                                if ranvar==1:
                                    urls=option_heads_image
                                    string+="You landed on `"+option_heads+"`\n"
                                else:
                                    urls=option_tails_image
                                    string+="You landed on `"+option_tails+"`\n"
                            else:
                                urls=None
                            if pickvar==ranvar: #Win       
                                c.execute("UPDATE {} SET currency=? WHERE id=?".format(self.table),(data[0]+gamble, self.message.author.id))                      
                                string+="You won `"+str(gamble)+"` "+self.name+".\nYour new balance is `"+str(data[0]+gamble)+"` "+self.name+"."
                            else: #Loss
                                c.execute("UPDATE {} SET currency=? WHERE id=?".format(self.table),(data[0]-gamble, self.message.author.id))
                                string+="You lost `"+str(gamble)+"` "+self.name+".\nYour new balance is `"+str(data[0]-gamble)+"` "+self.name+"."
                            em=embed(message=self.message, description=string, author=self.author, image=urls, optional_name=self.optional)
                        else:
                            em=embed(message=self.message, description="You don't have enough "+self.name+".", author=self.author)
        return em
    # block = If you should be able to check other user's banks or not.
    def bank(self, display_image=None, block=False):
        self.url=display_image
        checker=self.message.author
        em=None
        try: 
            gotdata=self.message.mentions[0]
        except (ValueError, IndexError):
            pass
        else:
            checker=self.message.mentions[0]
        if block==True:
            checker=self.message.author 
        
        with dbopen('example.db') as c:

            c.execute("SELECT currency FROM {} WHERE id=?".format(self.table), (checker.id,))
            data=c.fetchone()
        string=""
        if self.message.author.id==checker.id:
           string="You have `"+str(data[0])+"` "+self.name+"."
        else:
            string=checker.mention+" has `"+str(data[0])+"` "+self.name+"."
        em=embed(message=self.message, description=string, author=self.author, image=display_image, optional_name=self.optional)
        return em
    # Displays a leaderboard of the users with the most "currency" on the server
    def top(self, display_number, display_image=None, display_footer=None):
        self.url=display_image
        self.footer=display_footer
        string=''
        counter2=0
        with dbopen('example.db') as c:
            c.execute("SELECT id,currency FROM {} ORDER BY currency DESC LIMIT {}".format(self.table, display_number))
            data=c.fetchall()
        counter=0
        for value in data:
            find=discord.utils.get(self.message.server.members, id=value[0])
            optionalname=""
            mention=""
            try:
                if self.optional:
                    optionalname=find.name
                mention=find.mention
            except (AttributeError):
                if self.optional:
                    optionalname="<member missing>"
                mention="<@{}>".format(value[0])
            counter+=1
            string+='**'+str(counter)+'. '+optionalname+' '+mention+': '+str(value[1])+" "+self.name+"** \n"
        em=embed(message=self.message,title=self.name[0].upper()+self.name[1:].strip()+' Leaderboard', description=string, image=display_image)

        return em
    def reward(self, display_image=None):
        em=embed(self.message,description="You entered the command incorrectly")
        try:
            gotdata=self.message.mentions[0]
        except (IndexError, ValueError):
            gotdata='null'
        else:
            send=self.message.content[self.message.content.find(self.message.mentions[0].id)+len(self.message.mentions[0].id)+1:].strip()
            try:
                gotdata=int(send)
            except (IndexError, ValueError):
                pass
            else:

                send=int(send)
                if send>=0: #and self.message.mentions[0].bot==False:
                    with dbopen('example.db') as c:
                        c.execute("SELECT currency FROM {} WHERE id=?".format(self.table), (self.message.mentions[0].id,))
                        data=c.fetchone()
                        c.execute("UPDATE {} SET currency=? WHERE id=?".format(self.table),(data[0]+send,self.message.mentions[0].id))     
                        em=embed(message=self.message, description="You rewarded "+self.message.mentions[0].mention+" with `"+str(send)+"` "+self.name+".", author=self.author, image=display_image, optional_name=self.optional)
        return em
    def remove(self, ids):
        with dbopen("example.db") as c:
            c.execute("DELETE FROM {} WHERE id=?".format(self.table), (ids,))
    def strip(self, display_image=None):
        em=embed(self.message,description="You entered the command incorrectly")
        try:
            gotdata=self.message.mentions[0]
        except (IndexError, ValueError):
            gotdata='null'
        else:
            send=self.message.content[self.message.content.find(self.message.mentions[0].id)+len(self.message.mentions[0].id)+1:].strip()
            try:
                gotdata=int(send)
            except (IndexError, ValueError):
                pass
            else:

                send=int(send)
                if send>=0: #and self.message.mentions[0].bot==False:
                    with dbopen('example.db') as c:
                        c.execute("SELECT currency FROM {} WHERE id=?".format(self.table), (self.message.mentions[0].id,))
                        data=c.fetchone()
                        c.execute("UPDATE {} SET currency=? WHERE id=?".format(self.table),(data[0]-send,self.message.mentions[0].id))     
                        em=embed(message=self.message, description="You stripped away "+str(send)+" from "+self.message.mentions[0].mention+"` "+self.name+".", author=self.author, image=display_image, optional_name=self.optional)
        return em
    def gift(self, display_image=None):
        em=embed(self.message,description="You entered the command incorrectly")
        try:
            gotdata=self.message.mentions[0]
        except (IndexError, ValueError):
            gotdata='null'
        else:
            if self.message.author.id != self.message.mentions[0].id:
                send=self.message.content[self.message.content.find(self.message.mentions[0].id)+len(self.message.mentions[0].id)+1:].strip()
                try:
                    gotdata=int(send)
                except (IndexError, ValueError):
                    pass
                else:
                    send=int(send)
                    if send>=0: #and self.message.mentions[0].bot==False:
                        with dbopen('example.db') as c:
                            c.execute("SELECT currency FROM {} WHERE id=?".format(self.table), (self.message.author.id,))
                            data=c.fetchone()
                            if data[0]>=send:
                                c.execute("SELECT currency FROM {} WHERE id=?".format(self.table), (self.message.mentions[0].id,))
                                data2=c.fetchone()
                                c.execute("UPDATE {0} SET currency=? WHERE id=?".format(self.table),(data[0]-send, self.message.author.id))
                                c.execute("UPDATE {0} SET currency=? WHERE id=?".format(self.table),(data2[0]+send,self.message.mentions[0].id))

                                string="You gifted "+self.message.mentions[0].mention+" `"+str(send)+"` "+self.name
                                em=embed(message=self.message, description=string, author=self.author, image=display_image, optional_name=self.optional)
                            else:
                                em=embed(message=self.message, description="You don't have enough "+self.name+".", author=self.author)
        return em
    # cooldown = Cooldown in hours before you can work again
    # custom_outputs = If you want a string or a list containing own made outputs for the work command
    #   
    def work(self, cooldown=4, aquire_range=(350,500), custom_outputs=None, display_image=None):
        string=""
        coins=random.randint(aquire_range[0],aquire_range[1])
        if custom_outputs==None:
            string="You worked for a few hours"
        else:
            if type(custom_outputs) is list:
                string=custom_outputs[random.randint(0,len(custom_outputs)-1)]
            elif type(custom_outputs) is str:
                string=custom_outputs
        


        with dbopen('example.db') as c:
            if self.perk:     
                c.execute("SELECT id FROM {} WHERE name IN(SELECT name FROM {} WHERE id=?)".format(self.table4,self.table3),(self.message.author.id,))
                data=c.fetchall()
                for perk in data:
                    if perk[0]==5:
                        coins=coins*2
                    if perk[0]==7:
                        cooldown=1
            c.execute('''CREATE TABLE if not exists {} (cd_id text, date text, mode text, FOREIGN KEY(cd_id) REFERENCES {}(id))'''.format(self.table2, self.table))
            c.execute("SELECT currency FROM {} WHERE id IN(SELECT cd_id FROM {} WHERE mode=? and id=?)".format(self.table, self.table2),("work",self.message.author.id))
            data=c.fetchall()
            if len(data)==0:
                c.execute("INSERT INTO {} values ( ?, ?, ?)".format(self.table2),(self.message.author.id,str(datetime.now()+timedelta(hours=cooldown)),"work"))
                c.execute("SELECT currency FROM {} WHERE id=?".format(self.table),(self.message.author.id,))
                data=c.fetchone()
                c.execute("UPDATE {} SET currency=? WHERE id=?".format(self.table),(data[0]+coins,self.message.author.id))
                em=embed(message=self.message, description=string+" and earned `"+str(coins)+"` "+self.name+".\nYour new balance is `"+str(data[0]+coins)+"` "+self.name+".", author=self.author, image=display_image, optional_name=self.optional)
            else:
                curr=data[0]
                c.execute("SELECT date FROM {} WHERE cd_id=? and mode=?".format(self.table2),(self.message.author.id,"work"))
                data=c.fetchone()
                datetime_object = datetime.strptime(data[0],'%Y-%m-%d %H:%M:%S.%f')
                if datetime_object<=datetime.now():
                    c.execute("UPDATE {} SET currency=? WHERE id=?".format(self.table),(curr[0]+coins,self.message.author.id))
                    c.execute("UPDATE {} SET date=? WHERE cd_id=? and mode=?".format(self.table2),(str(datetime.now()+timedelta(hours=cooldown)),self.message.author.id,"work"))
                    em=embed(message=self.message, description=string+" and earned `"+str(coins)+"` "+self.name+".\nYour new balance is `"+str(curr[0]+coins)+"` "+self.name+".", author=self.author, image=display_image, optional_name=self.optional)
                else:
                    em=embed(message=self.message, description="You need some rest! You can work again in "+str(datetime_object-datetime.today())[:str(datetime_object-datetime.today()).find(".")].strip()+" hours.", author=self.author)
            return em

    def drop(self):
        with dbopen("example.db") as c:
            c.execute("DROP TABLE {}".format(self.table))
            c.execute('''CREATE TABLE if not exists {} (id text PRIMARY KEY, date text, currency integer, counter integer)'''.format(self.table))
        # Make tidier for fuck sake , Prolly change database layout.
    def steal(self, cooldown=4, aquire_range=(50,500), custom_outputs=None, caught=False, caught_perc=50, caught_range=(50,100), display_image=None):
        em=embed(self.message,description="You entered the command incorrectly") 
        try:
            gotdata=self.message.mentions[0]
        except (IndexError, ValueError):
            pass
        else:
            if self.message.mentions[0].bot==False and self.message.author.id != self.message.mentions[0].id:
                coins=random.randint(aquire_range[0],aquire_range[1])
                    
                if custom_outputs:
                    if type(custom_outputs) is list:
                        string=custom_outputs[random.randint(0,len(custom_outputs)-1)]
                    elif type(custom_outputs) is str:
                        string=custom_outputs
                check=101
                if caught:
                    check=random.randint(0,100)
                    if check<=caught_perc:
                        coins=-random.randint(caught_range[0],caught_range[1])

                with dbopen('example.db') as c:
                    c.execute('''CREATE TABLE if not exists {} (cd_id text, date text, mode text, FOREIGN KEY(cd_id) REFERENCES {}(id))'''.format(self.table2, self.table))
                    if self.perk:     
                        c.execute("SELECT id FROM {} WHERE name IN(SELECT name FROM {} WHERE id=?)".format(self.table4,self.table3),(self.message.author.id,))
                        data=c.fetchall()
                        for perk in data:
                            if perk[0]==6:
                                coins=coins*2
                            if perk[0]==7:
                                cooldown=1
                    c.execute("SELECT currency FROM {} WHERE id IN(SELECT cd_id FROM {} WHERE mode=? and id=?)".format(self.table, self.table2),("steal",self.message.author.id))
                    data=c.fetchall()
                    if len(data)==0:
                        c.execute("INSERT INTO {} values ( ?, ?, ?)".format(self.table2),(self.message.author.id,str(datetime.now()+timedelta(hours=cooldown)),"steal"))
                        c.execute("SELECT currency FROM {} WHERE id=?".format(self.table),(self.message.author.id,))
                        data=c.fetchone()
                        c.execute("UPDATE {} SET currency=? WHERE id=?".format(self.table),(data[0]+coins,self.message.author.id)) #Assigns the stealer his pacs
                        em=embed(message=self.message, description="You got caught and lost `"+str(-coins)+"` "+self.name+".\nYour new balance is `"+str(data[0]+coins)+"` "+self.name+".", author=self.author, image=display_image, optional_name=self.optional)
                        if not check<=caught_perc:
                            em=embed(message=self.message, description="You stole `"+str(coins)+"` "+self.name+" from "+self.message.mentions[0].mention+".\nYour new balance is `"+str(data[0]+coins)+"` "+self.name+".", author=self.author, image=display_image, optional_name=self.optional)
                            c.execute("SELECT currency FROM {} WHERE id=?".format(self.table),(self.message.mentions[0].id,)) 
                            data2=c.fetchone()
                            c.execute("UPDATE {} SET currency=? WHERE id=?".format(self.table),(data2[0]-coins,self.message.mentions[0].id)) 

                    else:
                        curr=data[0]
                        c.execute("SELECT date FROM {} WHERE cd_id=? and mode=?".format(self.table2),(self.message.author.id,"steal"))
                        data=c.fetchone()
                        datetime_object = datetime.strptime(data[0],'%Y-%m-%d %H:%M:%S.%f')
                        if datetime_object<=datetime.now():
                            c.execute("UPDATE {} SET currency=? WHERE id=?".format(self.table),(curr[0]+coins,self.message.author.id))
                            c.execute("UPDATE {} SET date=? WHERE cd_id=? and mode=?".format(self.table2),(str(datetime.now()+timedelta(hours=cooldown)),self.message.author.id,"steal"))
                            em=embed(message=self.message, description="You got caught and lost `"+str(-coins)+"` "+self.name+".\nYour new balance is `"+str(curr[0]+coins)+"` "+self.name+".", author=self.author, image=display_image, optional_name=self.optional)
                            if not check<=caught_perc:
                                c.execute("SELECT currency FROM {} WHERE id=?".format(self.table),(self.message.mentions[0].id,)) 
                                data2=c.fetchone()
                                c.execute("UPDATE {} SET currency=? WHERE id=?".format(self.table),(data2[0]-coins,self.message.mentions[0].id))
                                em=embed(message=self.message, description="You stole `"+str(coins)+"` "+self.name+" from "+self.message.mentions[0].mention+".\nYour new balance is `"+str(curr[0]+coins)+"` "+self.name+".", author=self.author, image=display_image, optional_name=self.optional)
                        else:
                            em=embed(message=self.message, description="You need some rest! You can only steal again in "+str(datetime_object-datetime.today())[:str(datetime_object-datetime.today()).find(".")].strip()+" hours.", author=self.author, image=display_image, optional_name=self.optional)
        return em
   
