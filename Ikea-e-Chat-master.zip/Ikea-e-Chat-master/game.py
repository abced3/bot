import discord
import asyncio
import logging
import random
import sys
import json
import fileinput
from datetime import datetime, timedelta, date
import secrets
import math
import os





def randomizer(members):
    mem=[]
    counter=0
    for line in members:
        counter+=1
        mem.append(line.id)  
    ids=mem[secrets.randbelow(len(mem))]
    even=[]
    uneven=[]
    string1=""
    string2=""
    string3=""
    ratio=0
    for i in range(len(ids)):
        if int(ids[i])%2==0:
            even.append(int(ids[i]))
        else:
            uneven.append(int(ids[i]))
    for line in even:
        string1+=str(line)
    for line in uneven:
        string2+=str(line)
    if len(string1)==0:
        if secrets.randbelow(2)==1:
            return True
        else:
            return False
    if len(string2)==0:
        if secrets.randbelow(2)==1:
            return True
        else:
            return False
    count=0
    ratio=0
    if len(string1)>len(string2):
        if len(string2)!=0:
            ratio=len(string1)/len(string2)
        if ratio==2:
            count=int(round(ratio)*2)+1
        elif ratio==3.5:
            count=int(round(ratio)*2)-1
        elif ratio==8:
            count=int(round(ratio)*2)-1
        elif ratio==17:
            count=int(round(ratio)*2)-4
        else:
            count=int(round(ratio)*2)
        for i in range(count):
            string3+=str(int(secrets.choice(ids))%2)
        if len(string3)==2:
            if string3.count("0")==2 or string3.count("1")==2:
                return True #win   
            else:
                return False #lose
        elif string3.count("1")>=2:
            return True #Win 
        else:
            return False #lose
    elif len(string2)>len(string1):
        if len(string1)!=0:
            ratio=len(string2)/len(string1)
        if ratio==2:
            count=int(round(ratio)*2)+1
        elif ratio==3.5:
            count=int(round(ratio)*2)-1
        elif ratio==8:
            count=int(round(ratio)*2)-1
        elif ratio==17:
            count=int(round(ratio)*2)-4
        else:
            count=int(round(ratio)*2)
        for i in range(count):
            string3+=str(int(secrets.choice(ids))%2)
        if len(string3)==2:
            if string3.count("0")==2 or string3.count("1")==2:
                return True #win   
            else:
                return False #lose
        elif string3.count("0")>=2:
            return True #win   
        else:
            return False #lose
    else:
        ratio=1
        for i in range(int(round(ratio)*2)):
            string3+=str(int(secrets.choice(ids))%2)
        if string3.count("0")==2 or string3.count("1")==2:
            return True #win   
        else:
            return False #lose