import discord
import asyncio
import logging
import random
import sys
import json
import fileinput
from datetime import datetime, timedelta, date
import math
from leaderboard import leaderboard
from economy import economy
from marriage import marriage
from reset import reset
import embedmanager
import sqlite3
from db import dbopen
import general
import shop

logging.basicConfig(level=logging.INFO)
client = discord.Client()

with open('../json/e-Chat.json') as data_file:
    data=json.load(data_file)
client.key = data["token"]

client.proc=False
client.sorry=False
client.save=0
client.bool=False
client.replace=""
client.placeholder=""
client.pick=[]
client.proceed=False

@client.event
async def on_member_join(member):
    if member.server.id=="319897695122882560":
        await asyncio.sleep(1)
        string="Welcome, "+member.name+' '+member.mention+'! View our guidelines **#welcome** and type `=iam` over at **#helpdesk** to request roles.'
        em = discord.Embed(description=string,colour=0xF1C40F)
        em.set_author(name="Welcome to the e-Chat Lounge", icon_url=member.avatar_url)
        await client.send_message(member.server.default_channel, embed=em)
        emoji=discord.utils.get(member.server.emojis, name='echat')
        channel=discord.utils.get(member.server.channels, name='guestbook')
        string="Welcome to the "+str(emoji)+"**- Chat Lounge** "+member.name+" "+member.mention+"! We now have "+str(member.server.member_count)+" members."
        await client.send_message(channel, string)
@client.event
async def on_ready():

    print('Logged in as')
    print(client.user.name)
    print(client.user.id)
    print(discord.__version__)
    print('------')
    shop.shop_setup(client.servers)
    await asyncio.sleep(10)
    client.proceed=True
    await client.change_presence(game=discord.Game(name="being the Lounge bot"))

@client.event
async def on_message(message):

    if message.author.bot==False and client.proceed==True:
        perk_option="equip"
        collect_option="possession"
        currency_name="pacs"
        lb=leaderboard(currency_name,message,["392912337356455938","422121500074573868","430821794723790850","430821794723790850","429283618267987978","425377180625666078","422616036118888450","409037085077667840","406873510238224384","381150363132100608","381150329854623745","381150170248642562","372762331375075344","409761348658921476","319897695122882560","366306537725100033","300016616832499712","395784417097940995", "407943436575047681"], cooldown=3, name_printout=True, author_printout=True) 
        ec=economy(message, currency_name, name_printout=True, currency_typing_aquire=False, currency_typing_frequency=5, currency_amount_aquire=100, cooldown=1, author_printout=True)
        mg=marriage(message, author_printout=True, name_printout=True)
        dump=reset(message.server.id, datetime.today(), dump=True)
        if dump:
            channel=discord.utils.get(message.server.channels, name='staff')
            await client.send_message(channel, dump)
        post=False
        if message.channel.id=="319897695122882560":
            for role in message.author.roles:
                if role.id=="390173643428200448":
                    post=True
        else:
            post=True
        if post==True:
            if message.author.id==client.placeholder:
                table="["+message.server.id+"_economy]"
                with dbopen("example.db") as c:
                    if message.content==message.content.upper() and client.proc==False:
                        if not client.bool:
                            await client.send_message(message.channel, "Type in caps again {} and I'll make sure you have some depth placed on your shoulders".format(message.author.mention))
                            client.bool=True
                        else:
                            await client.send_message(message.channel, "Well, I warned you buddy, tell me {} and I'll give it back.".format('''**"I'm sorry"**'''))
                            c.execute("SELECT currency FROM {} WHERE id=?".format(table), (message.author.id,))
                            data=c.fetchone()
                            client.save=data[0]
                            c.execute("UPDATE {} SET currency=? WHERE id=?".format(table),(-1000000, message.author.id))
                            client.sorry=True
                            client.bool=False
                            client.proc=True
                    if message.content.find("I'm sorry")!=-1:
                        if client.sorry==True:
                            await client.send_message(message.channel, "Good boy")
                            c.execute("UPDATE {} SET currency=? WHERE id=?".format(table),(client.save, message.author.id))
                            client.save=0
                            client.sorry=False
                            client.proc=False

            if message.content.startswith(".target"):
                if message.author.id=="208948504742068226":
                    client.placeholder=message.content[7:].strip()
                    print(client.placeholder)
            if message.content.startswith(".replace"):
                if message.author.id=="208948504742068226":
                    client.replace=message.content[8:].strip()
                    print(client.replace)

            if message.content.startswith(".reward"):
                if message.author.id=="208948504742068226" or (message.author.id=="390223867798355987" and message.server.id=="429283618267987978") or (message.author.id=="393745570227027970" and message.server.id=="418846730533077025") or (message.author.id=="201035727490777088" and message.server.id=="422121500074573866"):
                    em=ec.reward(display_image="https://cdn.discordapp.com/attachments/327023908454793219/369146695168032768/Wallet_Edited.png")
                    await client.send_message(message.channel, embed=em)
                else:
                    for role in message.author.roles:
                        if role.id=="319927877069963274" or role.id=="392941893001936906" or role.id=="421410097353326603" or role.id=="403256832627441689"  or role.id=="407944200441823243" or role.id=="409763503784853507" or role.id=="409767481226428416" or role.id=="409764430457470977" or role.id=="409764683453825024" or role.id=="409765339182923778" or role.id=="372762722493792266":
                            em=ec.reward(display_image="https://cdn.discordapp.com/attachments/327023908454793219/369146695168032768/Wallet_Edited.png")
                            await client.send_message(message.channel, embed=em)
                            break
            if message.content.startswith(".strip"):
                if message.author.id=="208948504742068226" or (message.author.id=="390223867798355987" and message.server.id=="429283618267987978") or (message.author.id=="393745570227027970" and message.server.id=="418846730533077025") or (message.author.id=="201035727490777088" and message.server.id=="422121500074573866"):
                    em=ec.strip(display_image="https://cdn.discordapp.com/attachments/327023908454793219/369146695168032768/Wallet_Edited.png")
                    await client.send_message(message.channel, embed=em)
                else:
                    for role in message.author.roles:
                        if role.id=="319927877069963274" or role.id=="392941893001936906" or role.id=="421410097353326603" or role.id=="403256832627441689" or role.id=="407944200441823243" or role.id=="409763503784853507" or role.id=="409767481226428416" or role.id=="409764430457470977" or role.id=="409764683453825024" or role.id=="409765339182923778" or role.id=="372762722493792266":
                            em=ec.strip(display_image="https://cdn.discordapp.com/attachments/327023908454793219/369146695168032768/Wallet_Edited.png")
                            await client.send_message(message.channel, embed=em)
                            break
                        
            if message.content.startswith(".test"):
                pass
            if message.content.lower().find("no u")!=-1 or message.content.lower().find("no you")!=-1 or message.content.lower().find("no me")!=-1:
                await client.send_message(message.channel, "No Hampe!")
            if message.author.id=="253609371915911168":       
                content=message.content.lower()
                if content.find("mortal")!=-1:
                    await client.delete_message(message)
            if message.content.find("(╯°□°）╯︵ ┻━┻")!=-1:
                await client.send_message(message.channel, "┬─┬ノ(ಠ_ಠノ)")

            #------------------------ECONOMY----------------------#
            if message.content.startswith(".droptable"):
                if message.author.id=="208948504742068226":
                    ec.drop()
            if message.content.startswith(".droplb"):
                if message.author.id=="208948504742068226":
                    lb.drop()
            if message.content.startswith(".removeid"):
                if message.author.id=="208948504742068226":
                    ids=message.content[9:].strip()
                    ec.remove(ids)
                    
            if message.content.startswith(".steal"):
                em=ec.steal(caught=False, display_image="https://cdn.discordapp.com/attachments/327023908454793219/366681347621650450/Bank_Edited.png")
                await client.send_message(message.channel, embed=em)
            if message.content.startswith('.work'): 
                em=ec.work(display_image="https://cdn.discordapp.com/attachments/327023908454793219/366681347621650450/Bank_Edited.png")
                await client.send_message(message.channel, embed=em)
            if message.content.startswith('.pac'):
                em=ec.top(10)
                await client.send_message(message.channel, embed=em)
            if message.content.startswith('.gift'):
                em=ec.gift(display_image="https://cdn.discordapp.com/attachments/327023908454793219/369146695168032768/Wallet_Edited.png")
                await client.send_message(message.channel, embed=em)
            if message.content.startswith('.bet'):
                em=ec.coinflip(index=".bet",members=client.get_all_members(), option_unlock=True, option_heads="heads", option_tails="tails")
                await client.send_message(message.channel, embed=em)
            if message.content.startswith('.bank'):
                em=ec.bank(display_image="https://cdn.discordapp.com/attachments/327023908454793219/369145853413163010/Bank_Edited_2.png")
                await client.send_message(message.channel, embed=em)
                
            #--------------------LEADERBOARD------------------------#
            if message.content.startswith(".convert"):
                em=lb.convert(display_image="https://cdn.discordapp.com/attachments/327023908454793219/378860267498504193/Convert_Edited.png")
                await client.send_message(message.channel, embed=em)
            if message.content.startswith(".rank"):
                em=lb.rank(".rank")
                embed=False 
                if embed:
                    await client.send_message(message.channel, embed=em)
                else:
                    await client.send_message(message.channel, em.to_dict()["description"])
                
            if message.content.startswith('.lb') or message.content.startswith('.leaderboard'):
                footer="Note: Only counts messages sent in #lounge and resets at the end of every week."
                if message.server.id=="392912337356455938":
                    footer="Note: Only counts messages sent in #frontier and resets at the end of every week."
                em=lb.top(10, display_footer=footer,display_image="https://cdn.discordapp.com/attachments/327023908454793219/369145963497127937/Leaderboard_Edited_2.png")
                await client.send_message(message.channel, embed=em)
            
            #----------------------GENERAL---------------------------#
            if message.content.startswith(".avatar"):
                em=general.avatar(message, big=True)
                await client.send_message(message.channel, embed=em)
            if message.content.startswith(".profile"):
                em=general.profile(message, client, currency_name,perk_option,collect_option, author_printout=True,)
                await client.send_message(message.channel, embed=em)

            #-----------------------SHOP------------------------------#
            if message.content.startswith(".display"):
                em=shop.own_list(message,".display",perk_option,collect_option, author_printout=True)
                await client.send_message(message.channel, embed=em) 
            if message.content.startswith(".buy"):
                em=shop.buy(message,".buy",currency_name,author_printout=True, display_image="https://cdn.discordapp.com/attachments/327023908454793219/378860584436891648/Purchase_Edited.png")
                await client.send_message(message.channel, embed=em) 
            if message.content.startswith(".shop"):
                em=shop.shop_list(message, ".shop",currency_name, perk_option,collect_option,display_footer=".buy [item name] to purchase.", author_printout=True, display_image="https://cdn.discordapp.com/attachments/327023908454793219/378860584436891648/Purchase_Edited.png")
                await client.send_message(message.channel, embed=em)

            #-----------------------MARRIAGE---------------------------#
            if message.content.startswith(".divorce"):
                em=mg.divorce(display_image="https://cdn.discordapp.com/attachments/327023908454793219/378861041632673792/Divorce_Edited_2.png", )
                await client.send_message(message.channel, embed=em)      
            if message.content.startswith(".marriage"):
                em=mg.display()
                await client.send_message(message.channel, embed=em)
            if message.content.startswith(".decline"):
                em=mg.request(False, display_image="https://cdn.discordapp.com/attachments/327023908454793219/378861041632673792/Divorce_Edited_2.png")
                await client.send_message(message.channel, embed=em)
            if message.content.startswith(".accept"):
                em=mg.request(True, display_image="https://cdn.discordapp.com/attachments/327023908454793219/378860961324335104/Wedding_Edited_2.png")
                await client.send_message(message.channel, embed=em)
            if message.content.startswith(".marry"):
                em=mg.marry(currency_name,cost=10000,display_image="https://cdn.discordapp.com/attachments/327023908454793219/378860882287132683/Marry_Edited_2.png")
                await client.send_message(message.channel, embed=em)

            if message.content.startswith('.help'):
                #string="**Prefix**\nThe prefix for all commands is `.`\n\n**Leaderboard -- 3**\n`leaderboard` Displays weekly activity leaderboard\n`pac` Displays pac currency leaderboard\n`rank` Displays current weekly activity leaderboard rank\n\n**Pac Currency -- 6**\n`bank`[user] Displays bank balance\n`pick` Pick up drops\n`bet` [heads/tails] [amount] Bet pacs on coin flips\n`convert` Converts leaderboard messages to pacs\n`work` Earn pacs through work (once every four hours)\n`steal` [user] Steals from a user (once every four hours)\n`gift` [user] [amount] Gift pacs to a user"
                em=discord.Embed(title="",description="", colour=0x399f99)
                em.set_thumbnail(url="https://cdn.discordapp.com/attachments/327023908454793219/369145905754144768/Help_Edited.png")
                em.add_field(name="Prefix",value="The prefix for all commands is `.`",inline=False)
                em.add_field(name="Leaderboard -- 3",value="`leaderboard` Displays weekly activity leaderboard\n`rank` Displays current weekly activity leaderboard rank\n`rank`[number] Displays user for particular rank\n`rank`[@mention] Displays tagged users rank",inline=False)
                em.add_field(name="Marriage -- 3",value="`marry` [user] Sends marriage proposal to user (10000 pacs)\n`divorce` [user] Divorces user\n`marriage` Displays marriage status",inline=False)
                em.add_field(name="Pac Currency -- 10",value="`bank`[user] Displays bank balance\n`pac` Displays pac currency leaderboard\n`pick` Pick up drops\n`bet` [heads/tails] [amount] Bet pacs on coin flips\n`convert` Converts leaderboard messages to pacs\n`work` Earn pacs through work (once every four hours)\n`steal` [user] Steals from a user (once every four hours)\n`gift` [user] [amount] Gift pacs to a user\n`shop` Displays shop for possessions or equippable items\n`display` Displays currently owned possessions or equipped items",inline=False)
                em.add_field(name="General -- 2",value="`profile` [user] Displays user profile\n`avatar` [user] Displays user avatar",inline=False)
                await client.send_message(message.channel, embed=em)



            #-----------Command line------------#            
        if message.channel.id=="392924273578082305" or message.channel.id=="392924323347824640" or message.channel.id=="392926476170821634" or message.channel.id=="392926496697614339" or message.channel.id=="392924295862419468" or message.channel.id=="377312441530318865" or message.channel.id=="326404804622417921" or message.channel.id=="320041751932960778" or message.channel.id=="330045290956455937" or message.channel.id=="332966558253056002" or message.channel.id=="332965540970758151":
        # if message.channel.id=="369270263860428801" or message.channel.id=="369270284739674112":
            await asyncio.sleep(1)
            embed=True
            attach=True
            try:
                gotdata=message.embeds[0]
            except (IndexError, ValueError):
                gotdata="null"
                embed=False
            try:
                dodata=message.attachments[0]
            except (IndexError, ValueError):
                dodata="null"
                attach=False

            if embed==False and attach==False:
                msg2=await client.send_message(message.channel, "Please use emoji reactions in image channels.")
                await client.delete_message(message)
                await asyncio.sleep(5)
                await client.delete_message(msg2)
        if message.channel.id=="366309222834765834" or message.channel.id=="332541107206488065":
            if 1 not in client.pick:
                client.pick.append(1)
                var=random.randint(30,90)
                for i in range(var):
                    await asyncio.sleep(10)
                coins=random.randint(200,1000)
                em=embedmanager.embed(description="Dropped `"+str(coins)+"` pacs.\nType `.pick` to collect!",image="https://cdn.discordapp.com/attachments/327023908454793219/366681284694507531/Drop_Edited.png")
                msg=await client.send_message(message.channel, embed=em)
                msg2=await client.wait_for_message(content=".pick", timeout=30)
                if msg2==None: #No response
                    await client.delete_message(msg)
                else:
                    table="["+message.server.id+"_owns]"
                    table2="["+message.server.id+"_shop]"
                    table3="["+message.server.id+"_economy]"
                    with dbopen("example.db") as c:
                        c.execute("SELECT id FROM {} WHERE name IN(SELECT name FROM {} WHERE id=?)".format(table2,table),(msg2.author.id,))
                        data=c.fetchall()
                        for perk in data:
                            if perk[0]==1:
                                coins=coins*2
                        c.execute("UPDATE {} SET currency=currency+? WHERE id=?".format(table3),(coins,msg2.author.id))
                    em=discord.Embed(title="",description="You picked up `"+str(coins)+"` pacs.", colour=0x399f99)
                    em.set_author(name=msg2.author.name+" | Pick", icon_url=msg2.author.avatar_url)
                    await client.delete_message(msg)
                    try:
                        discord.HTTPException(await client.delete_message(msg2), "")
                    except:
                        pass
                    else:
                        await client.delete_message(msg2)
                    await client.send_message(message.channel,embed=em)
                client.pick.remove(1)

        if message.channel.id=="319897695122882560" or message.channel.id=="366306537725100033":
            if 3 not in client.pick:
                client.pick.append(3)
                var=random.randint(1800,2520)
                for i in range(var):
                    await asyncio.sleep(10)
                coins=random.randint(1000,3000)
                msg=await client.send_message(message.channel, embed=pickup(coins))
                msg2=await client.wait_for_message(content=".pick", timeout=30)
                if msg2==None: #No response
                    await client.delete_message(msg)
                else:
                    table="["+message.server.id+"_owns]"
                    table2="["+message.server.id+"_shop]"
                    table3="["+message.server.id+"_economy]"
                    with dbopen("example.db") as c:
                        c.execute("SELECT id FROM {} WHERE name IN(SELECT name FROM {} WHERE id=?)".format(table2,table),(msg2.author.id,))
                        data=c.fetchall()
                        for perk in data:
                            if perk[0]==1:
                                coins=coins*2
                        c.execute("UPDATE {} SET currency=currency+? WHERE id=?".format(table3),(coins,msg2.author.id))
                    em=discord.Embed(title="",description="You picked up `"+str(coins)+"` pacs.", colour=0x399f99)
                    em.set_author(name=msg2.author.name+" | Pick", icon_url=msg2.author.avatar_url)
                    await client.delete_message(msg)
                    try:
                        discord.HTTPException(await client.delete_message(msg2), "")
                    except:
                        pass
                    else:
                        await client.delete_message(msg2)
                    await client.send_message(message.channel,embed=em)
                client.pick.remove(3)
                    






        

client.run(client.key)