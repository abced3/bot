import discord

def embed(message=None, title="",description="", colour=0x399f99, author=False, image=None, optional_name=False, footer=None):
    if optional_name:
        if description.find("<@")!=-1:
            try:
                gotdata=message.mentions[0]
            except (ValueError, IndexError):
                pass
            else:
                before=description[:description.find("<@")].strip()
                after=description[description.find("<@"):].strip()
                description=before+" "+message.mentions[0].name+" "+after
    em=discord.Embed(title=title, description=description, colour=colour)
    if author and message!=None:
        index=message.content
        if message.content.find(" ")!=-1:
            index=message.content[:message.content.find(" ")].strip()
        index=index[1:].strip()
        index=index[0].upper()+index[1:].strip()
        em.set_author(name=message.author.name+" | "+index, icon_url=message.author.avatar_url)
    if image:
        em.set_thumbnail(url=image)
    if footer:
        em.set_footer(text=footer)

    return em