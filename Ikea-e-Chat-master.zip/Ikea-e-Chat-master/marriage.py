import discord
import random
from datetime import datetime, timedelta, date
from game import randomizer
from db import dbopen
from general import get_date
from embedmanager import embed

# If you have the economy system activated. You can select a cost of the servers currency to marry
class marriage():
    def __init__(self, message, poly=False, perk_active=True, perk_currency_aquire=50, name_printout=False, author_printout=False):
        self.optional=name_printout
        self.author=author_printout
        self.message=message
        self.poly=poly
        self.table="["+message.server.id+"_marriage]"
        self.table2="["+message.server.id+"_economy]"
        self.table3="["+message.server.id+"_leaderboard]"
        with dbopen("example.db") as c:
            c.execute('''CREATE TABLE if not exists {} (send_id text, rec_id text, date text, status integer, perk integer)'''.format(self.table))
            if perk_active:
                c.execute("SELECT perk,send_id,rec_id FROM {} WHERE status=? AND (send_id=? OR rec_id=?)".format(self.table),(1,message.author.id,message.author.id))
                data=c.fetchone()
                if data!=None:
                    if data[0]==0 and data[2]==message.author.id:
                        c.execute("UPDATE {} SET perk=? WHERE rec_id=?".format(self.table),(1,message.author.id))
                        c.execute("SELECT currency FROM {} WHERE id=?".format(self.table2),(message.author.id,))
                        data=c.fetchone()
                        c.execute("UPDATE {} SET currency=? WHERE id=?".format(self.table2),(data[0]+perk_currency_aquire,message.author.id))
                    if data[0]==1 and data[1]==message.author.id:
                        c.execute("UPDATE {} SET perk=? WHERE send_id=?".format(self.table),(0,message.author.id))
                        c.execute("SELECT currency FROM {} WHERE id=?".format(self.table2),(message.author.id,))
                        data=c.fetchone()
                        c.execute("UPDATE {} SET currency=? WHERE id=?".format(self.table2),(data[0]+perk_currency_aquire,message.author.id))

    def divorce(self, display_image=None):
        if self.message.content==".divorce":
            with dbopen("example.db") as c:
                t=(1,self.message.author.id,self.message.author.id)
                c.execute("SELECT send_id, rec_id FROM {} WHERE status=? AND (send_id=? OR rec_id=?)".format(self.table),t)
                data=c.fetchone()
                if data==None:
                    em=embed(self.message,description="You're not married")
                else:
                    em=embed(message=self.message, description="You divorced and flushed the ring.\nTime to move on!", author=self.author, image=display_image, optional_name=self.optional)
                    t=(1,self.message.author.id,self.message.author.id)
                    c.execute("DELETE FROM {} WHERE status=? AND (send_id=? OR rec_id=?)".format(self.table),t)
        return em
    def display(self, display_image=None):
        with dbopen("example.db") as c:
            c.execute("SELECT send_id, rec_id, date FROM {} WHERE status=? AND (send_id=? OR rec_id=?)".format(self.table),(1,self.message.author.id,self.message.author.id))
            data=c.fetchone()
            if data==None:
                em=embed(self.message,description="You're not married to anyone")
            else:
                string=""
                ids=""
                try:
                    if data[0]==self.message.author.id:
                        ids=data[1]
                        member=discord.utils.get(self.message.server.members, id=ids)
                        string=member.mention
                    else:
                        ids=data[0]
                        member=discord.utils.get(self.message.server.members, id=ids)
                        string=member.mention
                except (AttributeError):
                    string="<@{}>".format(ids)
                em=embed(message=self.message, description=self.message.author.mention+" and "+string+" have been married since "+get_date(data[2][:data[2].find(".")].strip()), author=self.author, image=display_image, optional_name=self.optional)
            return em
    def marry(self, currency_name, cost=1000, display_image=None):
        em=embed(self.message,description="You entered the command incorrectly")
        try:
            gotdata=self.message.mentions[0]
        except (ValueError, IndexError):
            pass
        else:
            if self.message.author.id!=self.message.mentions[0].id:
                with dbopen("example.db") as c:
                    t=(1, self.message.author.id, self.message.author.id, self.message.mentions[0].id, self.message.mentions[0].id)
                    c.execute("SELECT send_id, rec_id FROM {} WHERE status=? AND ((send_id=? OR rec_id=?) OR (send_id=? OR rec_id=?))".format(self.table),t)
                    data=c.fetchall()
                    if len(data)==0:
                        marry=True
                        if cost:
                            c.execute("SELECT currency from {} WHERE id=?".format(self.table2), (self.message.author.id,))
                            data=c.fetchone()
                            if data[0]>=cost:
                                c.execute("UPDATE {} SET currency=? WHERE id=?".format(self.table2),(data[0]-cost,self.message.author.id))
                            else:
                                marry=False

                        if marry:
                            t=(self.message.author.id, self.message.mentions[0].id, str(datetime.now()), 0, 0)
                            c.execute("INSERT INTO {} values (?, ?, ?, ?, ?)".format(self.table),t)
                            string="You{} proposed to "+self.message.mentions[0].mention+"!"
                            if cost:
                                string2=" purchased a ring for `"+str(cost)+"` "+currency_name+" and"
                                string=string.format(string2)
                            else:
                                string=string.format("")
                            em=embed(message=self.message, description=string, author=self.author, image=display_image, optional_name=self.optional)
                            em.add_field(name="Awaiting "+self.message.mentions[0].name+"'s response...",value=".accept "+self.message.author.mention+" to accept\n.decline "+self.message.author.mention+" to decline") 
                        else:
                            em=embed(message=self.message, description="You don't have enough "+currency_name+".", author=self.author)
                    else:
                        em=embed(self.message,description="You can't marry if you, or the tagged user is already married")
        return em
    def request(self, decision, display_image=None):
        em=embed(self.message,description="You entered the command incorrectly")
        try:
            gotdata=self.message.mentions[0]
        except (ValueError, IndexError):
            pass
        else:
            with dbopen("example.db") as c:
                c.execute("SELECT status FROM {} WHERE rec_id=? and send_id=?".format(self.table),(self.message.author.id, self.message.mentions[0].id))
                data=c.fetchone()
                if data!=None:
                    if data[0]==0:
                        if decision==True:
                            c.execute("UPDATE {} SET date=?, status=? WHERE rec_id=? and send_id=?".format(self.table),(str(datetime.now()),1, self.message.author.id,self.message.mentions[0].id))
                            if not self.poly:
                                t=(0,self.message.author.id, self.message.author.id, self.message.mentions[0].id, self.message.mentions[0].id)
                                c.execute("DELETE FROM {} WHERE status=? AND ((send_id=? OR rec_id=?) OR (send_id=? OR rec_id=?))".format(self.table),t)
                            em=embed(message=self.message, description="Congratulations!\n"+self.message.author.mention+" and "+self.message.mentions[0].mention+" are now married.", author=self.author, image=display_image) 
                        if decision==False:
                            c.execute("DELETE FROM {} WHERE rec_id=? and send_id=?".format(self.table),(self.message.author.id, self.message.mentions[0].id))
                            em=embed(message=self.message, description="You declined the proposal and flushed the ring.", author=self.author, image=display_image, optional_name=self.optional) 
        return em

    