from datetime import timedelta, datetime
from db import dbopen
import sqlite3

def weekstart(today):
    weekday=int(today.weekday())
    hour=int(today.hour)
    minute=int(today.minute)
    second=int(today.second)
    micro=int(today.microsecond)
    data=str(today-timedelta(days=weekday, hours=hour, minutes=minute, seconds=second))
    data=data[:data.find(".")].strip()
    return data




def reset(server_id, date_today, dump=False):
    with dbopen("example.db") as c:
        table="RESETS_ALL"
        c.execute('''CREATE TABLE if not exists {} (server_id text, datetime text, desc text)'''.format(table))
        c.execute("SELECT datetime FROM {} WHERE server_id=? AND desc=?".format(table),(server_id,"leaderboard"))
        data=c.fetchone()
        if data==None:
            c.execute("INSERT INTO {} (server_id, datetime, desc) values (?, ?, ?)".format(table),(server_id,weekstart(date_today),"leaderboard"))
        else:
            datetime_object = datetime.strptime(data[0],'%Y-%m-%d %H:%M:%S')
            next_week=datetime_object+timedelta(days=7)
            if date_today>=next_week:
                string="``` Leaderboard dump\n\n"
                if dump:
                    c.execute("SELECT id,value FROM {}".format("["+server_id+"_leaderboard]"))
                    data=c.fetchall()
                    for line in data:
                        string+=str(line)+"\n"
                string+="```"
                c.execute("UPDATE {} SET datetime=? WHERE server_id=?".format(table),(next_week, server_id))
                c.execute("DROP TABLE {}".format("["+server_id+"_leaderboard]"))
                return string
        return False