import discord
import asyncio
import logging
import random
import sys
import json
import fileinput
from datetime import datetime, timedelta, date
import secrets
import math
import os

def setup(server):
    # Checks if the player have an "account" in the database, if not. it creates one.
    infile=False
    for line in file:
        if message.author.id in line:
            infile=True
    file.close()
    if infile==False:
        file=open(self.path,'a', encoding='utf-8')
        file.write(str(message.author.id)+":"+str(0)+"\n")
        file.close()