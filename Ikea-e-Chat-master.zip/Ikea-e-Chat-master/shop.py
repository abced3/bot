import discord
import random
from datetime import datetime, timedelta, date
from game import randomizer
from db import dbopen
from embedmanager import embed
import json

def shop_setup(servers):
    for server in servers:
        table="["+server.id+"_shop]"
        table2="["+server.id+"_owns]"
        with dbopen("example.db") as c:
            c.execute("""CREATE TABLE if not exists {} (id integer PRIMARY KEY, emj_name text, perk_desc text, name text, price integer, perk integer, req_name text)""".format(table))
            c.execute("""CREATE TABLE if not exists {} (id text, name text)""".format(table2, table))
            data=[]
            c.execute("SELECT * FROM {}".format(table))
            data=c.fetchone()
            if data==None:
                with open('shop.json') as data_file:
                    data=json.load(data_file)
                perks=data["perks"]
                collect=data["collectibles"]
                for i, effect in enumerate(perks["effects"]):
                    req=None
                    if perks["names"][i]=="Bank":
                        req="Keycard"
                    if perks["names"][i]=="Arbitrage":
                        req="Bank"
                    t=(perks["emotes"][i],effect,perks["names"][i],perks["prices"][i],1,req)
                    c.execute("INSERT INTO {} (emj_name, perk_desc, name, price, perk, req_name) values (?, ?, ?, ?, ?, ?)".format(table),t)
                for i, effect in enumerate(collect["emotes"]):
                    t=(collect["emotes"][i],"",collect["names"][i],collect["prices"][i],0)
                    c.execute("INSERT INTO {} (emj_name, perk_desc, name, price, perk) values (?, ?, ?, ?, ?)".format(table), t)

                

def shop_list(message, index, currency_name,  perk_opt, collect_opt, author_printout=False, display_image=None, display_footer=None):
    option=message.content[len(index):].strip()
    table="["+message.server.id+"_shop]"
    if len(option)!=0:
        with dbopen("example.db") as c:     
            c.execute("SELECT emj_name, perk_desc, name, price, perk FROM {}".format(table))
            data=c.fetchall()
            string_perks=""
            string_collectables=""
            for line in data:
                if line[4]==1:
                    string_perks+=line[0]+" "+line[2]+" - "+str(line[3])+" "+currency_name+" "+line[1]+"\n"
                if line[4]==0:
                    string_collectables+=line[0]+" "+line[2]+" - "+str(line[3])+" "+currency_name+" "+line[1]+"\n"
            if option==perk_opt or option==collect_opt:
                if option==perk_opt:
                    em=embed(title=perk_opt[0].upper()+perk_opt[1:].strip(),message=message, description=string_perks, author=author_printout, image=display_image, footer=display_footer)
                elif option==collect_opt:
                    em=embed(title=collect_opt[0].upper()+collect_opt[1:].strip(),message=message, description=string_collectables, author=author_printout, image=display_image, footer=display_footer)
            else:
                em=embed(message,description="You entered the command incorrectly")
    else:
        em=embed(title="List one of the options below",message=message, description="``"+perk_opt+"``\n``"+collect_opt+"``", author=author_printout, image=display_image)
    return em
def buy(message, index, currency_name, author_printout=False, display_image=None):
    table="["+message.server.id+"_shop]"
    table2="["+message.server.id+"_economy]"
    table3="["+message.server.id+"_owns]"
    request=message.content[len(index)+1:].strip()
    if request!="":
        request=request[0].upper()+request[1:].strip()
    with dbopen("example.db") as c:
        em=embed(message,description="You entered the command incorrectly")
        c.execute("SELECT price,req_name FROM {} WHERE name=?".format(table),(request,))
        data=c.fetchone()
        if data!=None:
            req=data[1]
            price=data[0]
            c.execute("SELECT currency FROM {} WHERE id=?".format(table2),(message.author.id,))
            data=c.fetchone()
            if data[0]>=price:
                check=False
                requirement=False
                if req==None:
                    requirement=True
                c.execute("SELECT name FROM {} WHERE id=?".format(table3),(message.author.id,))
                names=c.fetchall()
                for name in names:
                    if name[0]==req:
                        requirement=True
                    if name[0]==request:
                        check=True
                if check==False and requirement==True:
                    c.execute("UPDATE {} SET currency=? WHERE id=?".format(table2),(data[0]-price,message.author.id))
                    c.execute("INSERT INTO {} (id, name) values (?, ?)".format(table3),(message.author.id,request))
                    string="You purchased `"+request+"` for `"+str(price)+"` "+currency_name+".\nYour new balance is `"+str(data[0]-price)+"` "+currency_name+"."
                    em=embed(title="",message=message, description=string, author=author_printout, image=display_image)
                elif requirement==False:
                    em=embed(title="",message=message, description="You need to purchase `"+req+"` before buying this", author=author_printout)
                else:
                    em=embed(title="",message=message, description="You already own this.", author=author_printout)
            else:
                em=embed(title="",message=message, description="You don't have enough "+currency_name+".", author=author_printout)
        return em
def own_list(message, index, perk_opt, collect_opt, author_printout=False, display_image=None):
    option=message.content[len(index):].strip()
    if len(option)!=0:
        table="["+message.server.id+"_shop]"
        table2="["+message.server.id+"_owns]"
        with dbopen("example.db") as c:
            vary=""
            title=""
            if option==perk_opt or option==collect_opt:
                if option==perk_opt:
                    title=perk_opt[0].upper()+perk_opt[1:].strip()
                    c.execute("SELECT emj_name, perk_desc FROM {} WHERE name IN(SELECT name FROM {} WHERE id=? AND perk=?)".format(table,table2),(message.author.id,1))
                    vary="\n"
                if option==collect_opt:
                    title=collect_opt[0].upper()+collect_opt[1:].strip()
                    c.execute("SELECT emj_name, perk_desc FROM {} WHERE name IN(SELECT name FROM {} WHERE id=? AND perk=?)".format(table,table2),(message.author.id,0))
                    vary=" "
                data=c.fetchall()
                string=""
                if len(data)!=0:
                    for emj in data:
                        string+=emj[0]+" "+emj[1]+vary
                em=embed(title=title,message=message, description=string, author=author_printout)
            else:
                em=embed(message,description="You entered the command incorrectly")
    else:
        em=embed(title="Display one of the options below ",message=message,description="``"+perk_opt+"``\n``"+collect_opt+"``", author=author_printout)
    return em
        



    




